package PACKAGE_NAME;

import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int b = sc.nextInt(); // input b integer
        System.out.println(b);
        Random rc = new Random();
         int t rc.nextInt(); // diapason dla integer
        int tt rc.nextInt(11); // zadaem diaposon 0-10


        String bb = sc.nextLine();
        System.out.println(bb);

        sc.close(); // close scanner only in end program
    }


}
